from .data_loader import load_data

__all__ = ['load_data', 'load_data']