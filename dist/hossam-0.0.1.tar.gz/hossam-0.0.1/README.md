# hossam

Hossam Data Loader

이 라이브러리는 아이티윌에서 진행중인 머신러닝 데이터 분석 수업에서 사용되는 샘플 데이터를 로드하는 기능을 제공하는 라이브러리 입니다.
이광호 강사의 수업에서 활용되기는 것을 목적으로 합니다.

Usage:

```python
from hossam import load_data
df = load_data('AD-SALES')
```


License: MIT
